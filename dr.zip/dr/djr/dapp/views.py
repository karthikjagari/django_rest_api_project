from django.shortcuts import render

# Create your views here.
def booklist(request):
    return 'view'